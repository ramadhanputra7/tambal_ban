package com.example.nanodg.tambalban.ir.apend.slider.listener;

/**
 * @author S.Shahini
 * @since 11/27/16
 */

public interface OnSlideChangeListener {
    void onSlideChange(int selectedSlidePosition);
}
