package com.example.nanodg.tambalban.ir.apend.slider.listener;

/**
 * Created by Farzad Farazmand on 28,June,2017
 * farzad.farazmand@gmail.com
 */

public interface SlideClickListener {

    void onClicked(int id);

}
